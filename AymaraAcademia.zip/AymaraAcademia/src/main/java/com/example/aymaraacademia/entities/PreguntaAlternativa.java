package com.example.aymaraacademia.entities;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "PreguntaAlternativa")
public class PreguntaAlternativa {
    /*FALTAN LOS FK Y PK*/
}
