package com.example.aymaraacademia;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AymaraAcademiaApplication {

    public static void main(String[] args) {
        SpringApplication.run(AymaraAcademiaApplication.class, args);
    }

}
