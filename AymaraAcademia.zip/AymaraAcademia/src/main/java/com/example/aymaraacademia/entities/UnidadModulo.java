package com.example.aymaraacademia.entities;

public class UnidadModulo {
    /*FALTAN LOS PK Y FK*/
}
