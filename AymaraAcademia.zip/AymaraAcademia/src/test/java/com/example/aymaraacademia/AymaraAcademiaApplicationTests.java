package com.example.aymaraacademia;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AymaraAcademiaApplicationTests {

    @Test
    void contextLoads() {
    }

}
